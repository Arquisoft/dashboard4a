[![Codacy Badge](https://api.codacy.com/project/badge/Grade/2f5e9b234d9b4cbd8669629c299990ad)](https://www.codacy.com/app/jelabra/dashboard4a?utm_source=github.com&utm_medium=referral&utm_content=Arquisoft/dashboard4a&utm_campaign=badger)
[![Build Status](https://travis-ci.org/Arquisoft/dashboard4a.svg?branch=master)](https://travis-ci.org/Arquisoft/dashboard4a)
[![codecov](https://codecov.io/gh/Arquisoft/dashboard4a/branch/master/graph/badge.svg)](https://codecov.io/gh/Arquisoft/dashboard4a)


# participants0

[![Join the chat at https://gitter.im/Arquisoft/participants0](https://badges.gitter.im/Arquisoft/dashboard4a.svg)](https://gitter.im/Arquisoft/participants0?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

Skeleton of participants module

# Authors

- Herminio García González (@herminiogg)
- Jose Emilio Labra Gayo (@labra)

